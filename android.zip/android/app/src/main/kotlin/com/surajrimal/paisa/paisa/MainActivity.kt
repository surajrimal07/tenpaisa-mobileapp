package com.surajrimal.paisa.paisa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
